import React, { Component } from 'react';
import { List} from 'antd-mobile';

export default class ShopList extends Component {
  constructor(props) {
    super(props);
    
  }
  
  render() {
    const Item = List.Item;
    const Brief = Item.Brief;
    return (
      <div className="shop-list">
        <List renderHeader={() => '猜你喜欢'} className="my-list">
        <Item
          thumb="https://zos.alipayobjects.com/rmsportal/dKbkpPXKfvZzWCM.png"
          multipleLine
          onClick={() => {this.props.match.history.push('/detail')}}
        >
          <span>KFC</span> 
          <Brief>
            <p>[12店通用]10元代金券</p> 
            <div>
              <span className="price">10元</span>
              门市价：8元 
              <span className="pull-rigt">已售6</span>
            </div> 
          </Brief>
        </Item>
        <Item
          thumb="https://zos.alipayobjects.com/rmsportal/dKbkpPXKfvZzWCM.png"
          multipleLine
          onClick={() => {}}
        >
          <span>KFC</span> 
          <Brief>
            <p>[12店通用]10元代金券</p> 
            <div>
              <span className="price">10元</span>
              门市价：8元 
              <span className="pull-rigt">已售6</span>
            </div> 
          </Brief>
        </Item>
      </List>
      </div>
      
    );
  }
}
