import React, { Component } from 'react';
import { NavBar, Icon ,SearchBar} from 'antd-mobile';

export default class NavHeader extends Component {
  render() {
    return (
      <div className="nav">
        <NavBar
            mode="dark"
            leftContent="哈尔滨"
            rightContent={[
              <Icon key="1" type="ellipsis" />,
            ]}
          >
            <SearchBar
              className="nav-search"
              placeholder="输入搜索内容"
              disabled={true}
              ref={ref => this.manualFocusInst = ref}
            />
          </NavBar>
      </div>
    )
  }
}
